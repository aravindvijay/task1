// Create the AngularJS module Employees and Register the storageService with it  
var app = angular.module('Employees', ['storageService']);   


  
// Create the Controller EmployeeController  
app.controller('EmployeesController', ['$scope', 'getLocalStorage', function ($scope, getLocalStorage) {    
    $scope.appTitle = "LocalStorage Demo";    
    $scope.appHeadline = "AngularJS and HTML5";    
  
    //Read the Employee List from LocalStorage    
    $scope.employees = getLocalStorage.getEmployees();    
  
    //Count the Employee List    
    $scope.count = $scope.employees.length;    
  
  
    //Add Employee - using AngularJS push to add Employee in the Employee Object    
    //Call Update Employee to update the locally stored Employee List    
    //Reset the AngularJS Employee scope    
    //Update the Count    
    $scope.addEmployee = function () {    
        $scope.employees.push({ 'firstname': $scope.firstname, 'lastname': $scope.lastname, 'mobile': $scope.mobile, 'email': $scope.email});    
        getLocalStorage.updateEmployees($scope.employees);    
        $scope.empno = '';    
        $scope.empname = '';    
        $scope.empsalary = '';    
        $scope.count = $scope.employees.length;    
    };    
        
    //Delete Employee - Using AngularJS splice to remove the emp row from the Employee list    
    //All the Update Employee to update the locally stored Employee List    
    //Update the Count    
    $scope.deleteEmployee = function (emp) {                       
        $scope.employees.splice($scope.employees.indexOf(emp), 1);    
        getLocalStorage.updateEmployees($scope.employees);    
        $scope.count = $scope.employees.length;    
    };    
    $scope.editEmployee = function (emp) {
    	$scope.employee.
    	getLocalStorage.updateEmployees($scope.employees);    
        $scope.count = $scope.employees.length; 
    };
    
}]);  